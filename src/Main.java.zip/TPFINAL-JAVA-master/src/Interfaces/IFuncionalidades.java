package Interfaces;

public interface IFuncionalidades
{
    int contar();
    void listar();
    boolean eliminar();
    //boolean buscar();
    boolean agregar(Object o);
}
