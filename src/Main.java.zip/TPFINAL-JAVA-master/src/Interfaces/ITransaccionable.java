package Interfaces;

public interface ITransaccionable
{
    double calcularTotal();
}
